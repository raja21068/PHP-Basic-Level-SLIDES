<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VIKRAM</title>
<style type="text/css">
#wrapper
{
	width:900px;
	height:1000px;
	background-color:#666;
}
#header
{
	height:180px;
	width:900px;
	background-color:orange;
	float:left;
}
#body
{
	width:900px;
	height:780px;
	float:left;
	background-color:#03C;
}
#footer
{
	width:900px;
	height:40px;
	float:left;
	background-color:#F00;
}
#sidebar
{
	width:150px;
	height:820px;
	float:left;
	background-color:#0CF;
}
#sidebar2
{
	width:150px;
	height:820px;
	float:right;
	background-color:#09F;
}
</style>
</head>

<body>
<div id="wrapper">
<div id="header">Header Area</div>
<div id="body">
<div id="sidebar"><font color="#FF0000"> Side Bar Left</font></div>
<div id="sidebar2"><font color="#FF0000"> Side BAr Right</font> </div>
</div>
<div id="footer"> Footer Bar</div>

</div>
</body>
</html>