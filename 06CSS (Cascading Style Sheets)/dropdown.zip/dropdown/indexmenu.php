<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="cmsmenu_files/css3menu1/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VIKRAM</title>
<style type="text/css">
#wrapper
{
	width:900px;
	height:1000px;
	background-color:#666;
}
#header
{
	height:140px;
	width:900px;
	background-color:#090;
	float:left;
}
#body
{
	width:900px;
	height:780px;
	float:left;
	background-color:#03C;
}
#footer
{
	width:900px;
	height:40px;
	float:left;
	background-color:#F00;
}
#sidebar
{
	width:150px;
	height:820px;
	float:left;
	background-color:#0CF;
}
#sidebar2
{
	width:150px;
	height:820px;
	float:right;
	background-color:#09F;
}
#menu
{
	width:900px;
	height:40px;
	float:right;
	background-color:orange;
}
A:link {
text-decoration: none;
}
A:hover {
font-size:24; font-weight:bold; color: red;
}
</style>

</head>

<body>
<div id="wrapper">
<div id="header">Header Area</div>
<div align="center">
<div id="menu">
<ul id="css3menu1" class="topmenu">
	<li class="topfirst"><a href="#" style="height:18px;line-height:18px;">Home</a></li>
	<li class="topmenu"><a href="#" style="height:18px;line-height:18px;"><span>About us</span></a>
	</li>
	<li class="topmenu"><a href="#" style="height:18px;line-height:18px;">Faculty</a>
    	<ul>
		<li><a href="#">Item 1 .1 0</a>
        	<ul>
		<li><a href="#">Item 1 1.1</a></li>
		<li><a href="#">Item 1 1 .2</a></li>
		<li><a href="#">Item 1 1.3</a></li>
	</ul>
        </li>
		<li><a href="#">Item 1 1</a></li>
		<li><a href="#">Item 1 2</a></li>
	</ul>
    </li>
	<li class="toplast"><a href="#" style="height:18px;line-height:18px;">Department</a></li>
</ul>
</div>
</div>
<div id="body">
<div id="sidebar"><font color="#FF0000"> Side Bar Left</font></div>
<div id="sidebar2"><font color="#FF0000"> Side BAr Right</font> </div>
</div>
<div id="footer"> Footer Bar</div>

</div>
</body>
</html>