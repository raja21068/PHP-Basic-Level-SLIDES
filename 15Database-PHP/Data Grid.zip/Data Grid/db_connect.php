<?php
$con=mysql_connect('localhost','root','admin') or die('connect problem '.mysql_error()) ;
mysql_select_db('test') or die('DB Select problem');

?>