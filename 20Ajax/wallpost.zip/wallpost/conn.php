<?php session_start(); 
	$conn = mysql_connect("localhost" , "root" , "admin")
		or die(mysql_error());
	mysql_select_db("ajax" , $conn) 
		or die(mysql_error());
		
				
		
		