<?php include "conn.php" ?>
<?php

	$uname = $_POST[ "uname" ];
	$pass = $_POST[ "pass" ];
	
	
	$result = mysql_query( "SELECT * 
				FROM user 
				WHERE user_email = '".$uname."' 
				AND user_passowrd = '".$pass."'")
		
			or die(mysql_error() );
				
				
	
		if( $rows = mysql_fetch_array( $result )){
								
			$_SESSION["user_info"] = $rows ;
			
				header("Location:home.php");
					
			
			
			}
			
	
	


?>