<?php include "conn.php" ?>
<?php
	$user_id = $_SESSION["user_info"]["user_id"];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<title></title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style.css" rel="stylesheet">
</head>
<body onLoad="showUsers()">
<div class="wrapper">
	<header class="header">
       <img src="<?php 
	   	echo $_SESSION['user_info']['gender']== "male"? "img/male.png" : "img/female.png" ?>" alt="male" width="80" />
         <br/>
		 <?php
	 		echo $_SESSION['user_info']['user_name'];
			echo $_SESSION['user_info']['gender'];  ?>
       	<a href="javascript:void(0)" onClick="showData()">click</a>
	</header><!-- .header-->
	<div class="middle">
		<div class="container">
			<main class="content">
				<strong>Content:</strong> Sed placerat accumsan ligula. Aliquam felis magna, congue quis, tempus eu, aliquam vitae, ante. Cras neque justo, ultrices at, rhoncus a, facilisis eget, nisl. Quisque vitae pede. Nam et augue. Sed a elit. Ut vel massa. Suspendisse nibh pede, ultrices vitae, ultrices nec, mollis non, nibh. In sit amet pede quis leo vulputate hendrerit. Cras laoreet leo et justo auctor condimentum. Integer id enim. Suspendisse egestas, dui ac egestas mollis, libero orci hendrerit lacus, et malesuada lorem neque ac libero. Morbi tempor pulvinar pede. Donec vel elit.
			</main><!-- .content -->
		</div><!-- .container-->
		<aside class="left-sidebar">
			<strong>Left Sidebar:</strong> Integer velit. Vestibulum nisi nunc, accumsan ut, vehicula sit amet, porta a, mi. Nam nisl tellus, placerat eget, posuere eget, egestas eget, dui. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In elementum urna a eros. Integer iaculis. Maecenas vel elit.
		</aside><!-- .left-sidebar -->
		<aside class="right-sidebar" >
			<strong>Right Sidebar:</strong>         
		</aside><!-- .right-sidebar -->
	</div><!-- .middle-->
</div><!-- .wrapper -->
<footer class="footer">
<strong>Footer:</strong> Mus elit Morbi mus enim lacus at quis Nam eget morbi. Et semper urna urna non at cursus dolor vestibulum neque enim. Tellus interdum at laoreet laoreet lacinia lacinia sed Quisque justo quis. Hendrerit scelerisque lorem elit orci tempor tincidunt enim Phasellus dignissim tincidunt. Nunc vel et Sed nisl Vestibulum odio montes Aliquam volutpat pellentesque. Ut pede sagittis et quis nunc gravida porttitor ligula.
</footer><!-- .footer -->
</body>
</html>
<script> 
 function showUsers(){	 	
	 	setInterval( showData , 1000);		
		setInterval( showMsg , 1000);		 
	 }
 function showData(){
	xhr = new XMLHttpRequest();	
		xhr.onreadystatechange = function (){
				if(xhr.status == 200 && xhr.readyState == 4){
					document.getElementsByClassName("right-sidebar")[0].innerHTML = xhr.responseText;				
					}
			}	
			xhr.open("GET" , "online-user.php" , true);
			xhr.send(null);		
 }
</script>