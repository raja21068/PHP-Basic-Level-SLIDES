<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="pro.php" method="post" >
	<fieldset>
    	<legend>Login</legend>
        Username : <input type="text" name="uname" />
        <br/>
        Password : <input type="text" name="pass" />
        
        <br/>
        
        <input type="submit" name="btn"  />
        
        
    
    </fieldset>
</form>


</body>
</html>