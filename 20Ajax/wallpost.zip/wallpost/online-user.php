<?php include "conn.php" ?>
<?php
	$user_id = $_SESSION["user_info"]["user_id"];
?>
<?php

	  $query = "SELECT * FROM USER 
			  WHERE is_active = 1 
			  AND user_id != ".$user_id;
	  
	  $result = mysql_query( $query ) or 
	  		die(mysql_error());
		  
		  echo "<ul>";
		  while( $rows = mysql_fetch_array( $result )){
				  echo "<li>".$rows['user_name']."</li>";
				  
				  
			  }
		  
				?>